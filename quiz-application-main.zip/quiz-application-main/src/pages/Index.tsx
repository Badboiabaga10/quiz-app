
import Quiz from "@/components/Quiz";

const Index = () => {
  return <Quiz />;
};

export default Index;
